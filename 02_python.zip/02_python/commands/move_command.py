from .base_command import BaseCommand
import os
import shutil
from typing import List


class MoveCommand(BaseCommand):
    def __init__(self, options: List[str], args: List[str]) -> None:
        """
        Initialize the MoveCommand object.

        Args:
            options (List[str]): List of command options.
            args (List[str]): List of command arguments.
        """
        super().__init__(options, args)

        # Override the attributes inherited from BaseCommand
        self.description = 'Move a file or directory to another location'
        self.usage = 'Usage: mv [source] [destination]'

        # TODO 5-1: Initialize any additional attributes you may need.
        # Refer to list_command.py, grep_command.py to implement this.
        self.name = 'mv'
        self.options = options

        self.source_dir = self.args[0] if self.args else None
        self.destination_dir = self.args[1] if self.args else self.current_path
        if self.destination_dir[-1] != '/':
            self.destination_dir += '/'

    def execute(self) -> None:
        """
        Execute the move command.
        Supported options:
            -i: Prompt the user before overwriting an existing file.
            -v: Enable verbose mode (print detailed information)

        TODO 5-2: Implement the functionality to move a file or directory to another location.
        You may need to handle exceptions and print relevant error messages.
        """
        # Your code here
        if self.options == []:
            if self.file_exists(self.destination_dir, self.source_dir):
                print(
                    f"mv: cannot move '{self.source_dir}' to '{self.destination_dir}': Destination path '{self.destination_dir}{self.source_dir}' already exists")
            else:
                shutil.move(self.source_dir, self.destination_dir)

        elif '-i' in self.options and '-v' in self.options:
            print(
                f"mv: moving '{self.source_dir}' to '{self.destination_dir}'")
            if self.file_exists(self.destination_dir, self.source_dir):
                choice = input(
                    f"mv: overwrite '{self.destination_dir}{self.source_dir}'? (y/n)")
                if choice == 'y':
                    shutil.move(self.source_dir, self.destination_dir)
            else:
                shutil.move(self.source_dir, self.destination_dir)

        else:
            if '-i' in self.options:
                if self.file_exists(self.destination_dir, self.source_dir):
                    choice = input(
                        f"mv: overwrite '{self.destination_dir}{self.source_dir}'? (y/n)")
                    if choice == 'y':
                        shutil.move(self.source_dir, self.destination_dir)
                else:
                    shutil.move(self.source_dir, self.destination_dir)
            elif '-v' in self.options:
                print(
                    f"mv: moving '{self.source_dir}' to '{self.destination_dir}'")
                shutil.move(self.source_dir, self.destination_dir)

    def file_exists(self, directory: str, file_name: str) -> bool:
        """
        Check if a file exists in a directory.
        Feel free to use this method in your execute() method.

        Args:
            directory (str): The directory to check.
            file_name (str): The name of the file.

        Returns:
            bool: True if the file exists, False otherwise.
        """
        file_path = os.path.join(directory, file_name)
        return os.path.exists(file_path)
